package com.example.a413project

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class HistoryActivity : AppCompatActivity() {
    private lateinit var historyTextView: TextView
    private lateinit var summaryTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        historyTextView = findViewById(R.id.history_text_view)
        summaryTextView = findViewById(R.id.summary_text_view)

        // Load history and summary from SharedPreferences
        val handler = Handler(Looper.getMainLooper())
        handler.post {
            val history = loadHistory()
            val summary = summarizeHistory(history)

            historyTextView.text = history.joinToString("\n")
            summaryTextView.text = summary
        }
    }

    private fun loadHistory(): List<String> {
        val sharedPreferences = getSharedPreferences("game_history", Context.MODE_PRIVATE)
        val historySet = sharedPreferences.getStringSet("history", setOf()) ?: setOf()
        return historySet.toList()
    }

    private fun summarizeHistory(history: List<String>): String {
        val player1Wins = history.count { it == "Player 1 Wins!" }
        val player2Wins = history.count { it == "Player 2 Wins!" }
        val draws = history.count { it == "It's a Draw!" }

        return "Player 1 Wins: $player1Wins\nPlayer 2 Wins: $player2Wins\nDraws: $draws"
    }
}




