package com.example.a413project

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager

class SettingsActivity : AppCompatActivity() {
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val soundSwitch: Switch = findViewById(R.id.switch_sound)
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        soundSwitch.isChecked = sharedPreferences.getBoolean("sound_enabled", true)

        soundSwitch.setOnCheckedChangeListener { _, isChecked ->
            val editor = sharedPreferences.edit()
            editor.putBoolean("sound_enabled", isChecked)
            editor.apply()
        }
    }
}

