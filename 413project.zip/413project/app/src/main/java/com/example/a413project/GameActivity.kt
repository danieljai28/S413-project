package com.example.a413project


import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager
import kotlin.random.Random

class GameActivity : AppCompatActivity() {
    private lateinit var player1Dice: ImageView
    private lateinit var player2Dice: ImageView
    private lateinit var resultText: TextView
    private lateinit var rollButton: Button
    private lateinit var homeButton: Button // Added home button
    private lateinit var mediaPlayer: MediaPlayer
    private var soundEnabled: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        player1Dice = findViewById(R.id.player1_dice)
        player2Dice = findViewById(R.id.player2_dice)
        resultText = findViewById(R.id.result_text)
        rollButton = findViewById(R.id.roll_button)
        homeButton = findViewById(R.id.home_button) // Initialized home button

        mediaPlayer = MediaPlayer.create(this, R.raw.dice_roll)
        soundEnabled = intent.getBooleanExtra("sound_enabled", true)

        rollButton.setOnClickListener {
            rollDice()
        }

        homeButton.setOnClickListener {
            // Navigate back to the home page
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }
    }

    private fun rollDice() {
        if (soundEnabled) {
            mediaPlayer.start()
        }

        val player1Roll = Random.nextInt(1, 7)
        val player2Roll = Random.nextInt(1, 7)

        player1Dice.setImageResource(getDiceImage(player1Roll))
        player2Dice.setImageResource(getDiceImage(player2Roll))

        val result = when {
            player1Roll > player2Roll -> "Player 1 Wins!"
            player1Roll < player2Roll -> "Player 2 Wins!"
            else -> "It's a Draw!"
        }

        resultText.text = result

        // Save result to history
        saveResultToHistory(result)
    }

    private fun getDiceImage(roll: Int): Int {
        return when (roll) {
            1 -> R.drawable.dice1
            2 -> R.drawable.dice2
            3 -> R.drawable.dice3
            4 -> R.drawable.dice4
            5 -> R.drawable.dice5
            6 -> R.drawable.dice6
            else -> R.drawable.dice1
        }
    }

    private fun saveResultToHistory(result: String) {
        val sharedPreferences = getSharedPreferences("game_history", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val historySet = sharedPreferences.getStringSet("history", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        historySet.add(result)
        editor.putStringSet("history", historySet)
        editor.apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
    }
}



