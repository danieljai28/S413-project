package com.example.a413project
import android.annotation.SuppressLint
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class GameActivity : AppCompatActivity() {
    private lateinit var player1Dice: ImageView
    private lateinit var player2Dice: ImageView
    private lateinit var resultText: TextView
    private lateinit var rollButton: Button
    private lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        player1Dice = findViewById(R.id.player1_dice)
        player2Dice = findViewById(R.id.player2_dice)
        resultText = findViewById(R.id.result_text)
        rollButton = findViewById(R.id.roll_button)

        mediaPlayer = MediaPlayer.create(this, R.raw.dice_roll)

        rollButton.setOnClickListener {
            rollDice()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun rollDice() {
        mediaPlayer.start()

        val player1Roll = Random.nextInt(1, 7)
        val player2Roll = Random.nextInt(1, 7)

        player1Dice.setImageResource(getDiceImage(player1Roll))
        player2Dice.setImageResource(getDiceImage(player2Roll))

        when {
            player1Roll > player2Roll -> resultText.text = "Player 1 Wins!"
            player1Roll < player2Roll -> resultText.text = "Player 2 Wins!"
            else -> resultText.text = "It's a Draw!"
        }
    }

    private fun getDiceImage(roll: Int): Int {
        return when (roll) {
            1 -> R.drawable.dice1
            2 -> R.drawable.dice2
            3 -> R.drawable.dice3
            4 -> R.drawable.dice4
            5 -> R.drawable.dice5
            6 -> R.drawable.dice6
            else -> R.drawable.dice1
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
    }
}

